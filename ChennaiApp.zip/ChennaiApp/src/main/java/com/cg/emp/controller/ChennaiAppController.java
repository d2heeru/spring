package com.cg.emp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.emp.beans.Employee;
import com.cg.emp.exception.EmployeeException;
import com.cg.emp.service.EmployeeService;
@RestController
public class ChennaiAppController {
	
		@Autowired
		private EmployeeService employeeServive;
		
		@RequestMapping("/employees")
		public List<Employee> getEmployees() throws EmployeeException{
			return employeeServive.getAllEmployee();
		}
		@GetMapping("/employees/{id}")
		public Employee getEmployeeById(@PathVariable int id) throws EmployeeException {
			return employeeServive.getEmployeeById(id);
		}
		@PostMapping("/employees")
		public List<Employee> addEmployee(@RequestBody Employee emp) throws EmployeeException{
			return employeeServive.addEmployee(emp);
		}
		@DeleteMapping("/employees/{id}")
		public List<Employee> deleteEmployee(@PathVariable int id) throws EmployeeException{
			return employeeServive.deleteEmployee(id);
		
		}
	}