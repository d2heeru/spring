package com.cg.emp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.emp.beans.Employee;
import com.cg.emp.dao.EmployeeRepository;
import com.cg.emp.exception.EmployeeException;
@Service
public class EmployeeServiceImpl implements EmployeeService{
	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public List<Employee> getAllEmployee() throws EmployeeException {
		
		try {
			return employeeRepository.findAll();
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
	}

	@Override
	public List<Employee> addEmployee(Employee emp) throws EmployeeException {
		if(employeeRepository.existsById(emp.getId())) {
			throw new EmployeeException("Employee with Id" + emp.getId()+"already exist");
			
		}
		employeeRepository.save(emp);
		return getAllEmployee();
	}

	@Override
	public Employee getEmployeeById(int id) throws EmployeeException {
		if(!employeeRepository.existsById(id)) {
			throw new EmployeeException("Employee with Id"+id+"does not exists");
		}
			
		return employeeRepository.findById(id).get();
	}

	@Override
	public List<Employee> deleteEmployee(int id) throws EmployeeException {
		if(!employeeRepository.existsById(id)) {
			throw new EmployeeException("Employee with Id"+id+"does not exists");
		}
		employeeRepository.deleteById(id);
		return getAllEmployee();
	}

	@Override
	public List<EmployeeException> updateEmployee(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}
	

}
